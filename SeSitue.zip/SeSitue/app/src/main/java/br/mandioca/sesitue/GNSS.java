package br.mandioca.sesitue;

import android.Manifest;
import android.content.pm.PackageManager;
import android.location.GpsSatellite;
import android.location.GpsStatus;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.location.LocationProvider;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class GNSS extends AppCompatActivity implements LocationListener, GpsStatus.Listener {
    private LocationManager locManager; // O Gerente de localização
    private LocationProvider locProvider; // Provedor de localização
    private static final int REQUEST_LOCATION = 2;
    private TextView gnsstext;
    private String coords="Coordenadas GNSS";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gnss);
        locManager=(LocationManager) getSystemService(LOCATION_SERVICE);
        gnsstext=(TextView)findViewById(R.id.GNSSText);

    }
    @Override
    protected void onResume() {
        super.onResume();
        if (ActivityCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            ativaGPS();// A permissão foi dada
        } else {
            // Solicite a permissão
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION);
        }
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == REQUEST_LOCATION) {
            if(grantResults.length == 1 && grantResults[0] ==
                    PackageManager.PERMISSION_GRANTED) {
                // O usuário acabou de dar a permissão
                ativaGPS();
            }
            else {
                // O usuário não deu a permissão solicitada
                Toast.makeText(this,"Sua localização não será mostrada",Toast.LENGTH_SHORT).show();
                finish();
            }
        }
    }
    public void ativaGPS() {
        try {
            locProvider = locManager.getProvider(LocationManager.GPS_PROVIDER);
            locManager.requestLocationUpdates(locProvider.getName(), 30000, 1, this);
            locManager.addGpsStatusListener(this);
        } catch (SecurityException e) {
            e.printStackTrace();
        }
    }
    @Override
    protected void onPause() {
        super.onPause();
        desativaGPS();
    }

    public void desativaGPS() {
        try {
            locManager.removeUpdates(this);
            locManager.removeGpsStatusListener(this);
        } catch (SecurityException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onLocationChanged(Location location) {
        double latitude=location.getLatitude();
        double longitude=location.getLongitude();
        coords="Latitude:"+Location.convert(latitude,Location.FORMAT_SECONDS)+"\n"
                +"Longitude:"+Location.convert(longitude,Location.FORMAT_SECONDS);
        gnsstext.setText(coords);
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onProviderDisabled(String provider) {

    }

    @Override
    public void onGpsStatusChanged(int event) {
        // Alguma mudança no sistema GPS
        try {
            GpsStatus gpsStatus=locManager.getGpsStatus(null);
            // Informações do sistema estão encapsuladas no objeto gpsStatus
            if (gpsStatus!=null) {
                Iterable<GpsSatellite> sats = gpsStatus.getSatellites();
                for (GpsSatellite sat : sats) {
                    // processe as informações de cada satélite
                    coords+=sat.getPrn()+";"+sat.getAzimuth()+";"+sat.getElevation()+";"
                            +sat.getSnr()+";"+sat.usedInFix()+"\n";
                }
            }
        } catch (SecurityException e) {
            e.printStackTrace();
        }
        gnsstext.setText(coords);
    }
}
